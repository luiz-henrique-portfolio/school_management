from django.shortcuts import render, redirect
from employees.models import Employee, Cargo
from employees.forms import EmployeeForm, CargoForm
from django.contrib.auth.decorators import login_required


@login_required(login_url='login')
def home(request):	
    employees = Employee.objects.all()
    #return render(request, 'employees.html', {'employees': employees})
    return render(request, 'accounts/dashboard.html', {'employees': employees})

@login_required(login_url='login')        
def create_employee(request):
    form = EmployeeForm(request.POST or None)
    cargos = Cargo.objects.all()
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'employees-form.html', {'form': form, 'cargos' : cargos})

@login_required(login_url='login')
def update_employee(request, id):
    employee = Employee.objects.get(id=id)
    cargos = Cargo.objects.all()
    form = EmployeeForm(request.POST or None, instance=employee)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'employees-form.html', {'form': form, 'employees': employee, 'cargos' : cargos})

@login_required(login_url='login')
def delete_employee(request, id):
    employee = Employee.objects.get(id=id)
    if request.method == 'POST':
        employee.delete()
        return redirect('home')
    return render(request, 'employee-delete-confirm.html', {'employee': employee})


#CADASTRO DE CARGOS
@login_required(login_url='login')
def list_cargos(request):
    cargos = Cargo.objects.all()
    return render(request, 'list_cargos.html', {'cargos': cargos})
        
@login_required(login_url='login')
def create_cargo(request):
    form = CargoForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'cargos-form.html', {'form': form})

@login_required(login_url='login')
def update_cargo(request, id):
    cargo = Cargo.objects.get(id=id)
    form = CargoForm(request.POST or None, instance=cargo)
    if form.is_valid():
        form.save()
        return redirect('list_cargos')
    return render(request, 'cargos-form.html', {'form': form, 'cargos': cargo})

@login_required(login_url='login')
def delete_cargo(request, id):
    cargo = Cargo.objects.get(id=id)
    if request.method == 'POST':
        cargo.delete()
        return redirect('list_cargos')
    return render(request, 'cargo-delete-confirm.html', {'cargo': cargo})

