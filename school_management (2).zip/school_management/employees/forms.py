from django import forms
from employees.models import Employee, Cargo

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['nome', 'sobrenome', 'cpf', 'escolaridade', 'responsibility']

class CargoForm(forms.ModelForm):
    class Meta:
        model = Cargo
        fields = ['responsibility']
