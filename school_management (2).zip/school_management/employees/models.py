from django.db import models

# Nome, CPF, grau de instrução, função do foncionario
class Employee(models.Model):
    nome = models.CharField(max_length=100)
    sobrenome = models.CharField(max_length=100)
    cpf = models.CharField(max_length=100)
    escolaridade = models.CharField(max_length=100)
    responsibility = models.CharField(max_length=100)
    
    def __str__(self):
        return self.nome

class Cargo(models.Model):
    responsibility = models.CharField(max_length=100)
    
    
    def __str__(self):
        return self.nome
