from django.urls import path
from accounts import views as views_accounts
from employees import views as views_employees


urlpatterns = [
	path('register/', views_accounts.registerPage, name="register"),
	path('login/', views_accounts.loginPage, name="login"),  
	path('logout/', views_accounts.logoutUser, name="logout"),

	path('', views_employees.home, name='home'),
    path('novo/funcionario/', views_employees.create_employee, name='create_employee'),
    path('atualizar/funcionario-<int:id>/', views_employees.update_employee, name='update_employee'),
    path('apagar/funcionario-<int:id>/', views_employees.delete_employee, name='delete_employee'),

    path('lista_de_cargos/', views_employees.list_cargos, name='list_cargos'),
	path('novo/cargo/', views_employees.create_cargo, name='create_cargo'),
    path('atualizar/cargo-<int:id>/', views_employees.update_cargo, name='update_cargo'),
    path('apagar/cargo-<int:id>/', views_employees.delete_cargo, name='delete_cargo'),

]